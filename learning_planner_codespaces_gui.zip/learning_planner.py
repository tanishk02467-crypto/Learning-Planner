#!/usr/bin/env python3
"""PERSONALIZED LEARNING PATH & ASSESSMENT PLANNER (Python 3)

Single-file edition for Visual Studio Code. Uses only Python's standard library.

QUICK START
-----------
1. Open this file in VS Code.
2. Open Terminal -> New Terminal.
3. Run:  python learning_planner.py
   (On some Windows installations use: py learning_planner.py)

COMMANDS
--------
    python learning_planner.py menu
    python learning_planner.py plan
    python learning_planner.py plan data/week --strategy greedy --matrix
    python learning_planner.py validate data/small
    python learning_planner.py compare data/sample
    python learning_planner.py matrix data/week --all
    python learning_planner.py simulate data/small --missed 3,4
    python learning_planner.py plan data/week --csv plan.csv --json plan.json
    python learning_planner.py help

DATASET FORMAT
--------------
To use the original project's datasets, extract its data/ folder beside this file
(or run from the original project directory). A dataset folder contains:
    topics.csv       id,name,units,difficulty,value,mastery
    prereqs.csv      prereq,topic
    assessments.csv id,name,start,end,weight,optional,topics
    related.csv      a,b,effort                 (optional)
    mentors.csv      id,name,skills             (optional)
    config.cfg       key=value settings         (optional)

One unit represents 30 minutes. Topic IDs must be contiguous from 0, as in the
original datasets. The built-in sample works without any external files.

SCOPE NOTE
----------
This is a Python implementation of the portable single-file C edition's core
planner. It is not a line-by-line port of every original C++ component. The
original Win32/browser GUI, six-strategy optimisation suite, branch-and-bound,
DP workbench, shock runner, mentor recommendations and benchmarks are not
included in this compact single-file edition. The available strategies are
baseline and greedy; greedy is a heuristic, not a guaranteed global optimum.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional


# ---------------------------------------------------------------------------
# Data structures and defaults

@dataclass
class Topic:
    id: int
    name: str
    units: int
    difficulty: int
    value: float
    mastery: float


@dataclass
class Assessment:
    id: int
    name: str
    start: int
    end: int
    weight: float
    optional: int
    topics: list[int]


@dataclass
class Config:
    kind: str = "study"
    days: int = 14
    units_per_day: int = 8
    hard_units_per_day: int = 4
    hard_threshold: int = 7
    buffer: float = 1.25
    review_reserve: float = 0.20
    mastery_threshold: float = 0.70
    review_gaps: list[int] = field(default_factory=lambda: [1, 3, 7, 14])
    missed_days: list[int] = field(default_factory=list)


@dataclass
class Dataset:
    topics: list[Topic] = field(default_factory=list)
    prereqs: list[tuple[int, int]] = field(default_factory=list)
    related: list[tuple[int, int, int]] = field(default_factory=list)
    assessments: list[Assessment] = field(default_factory=list)
    mentors: list[tuple[int, str, list[int]]] = field(default_factory=list)
    cfg: Config = field(default_factory=Config)


@dataclass
class Session:
    day: int
    topic: int
    units: int
    review: bool = False


@dataclass
class Plan:
    strategy: str
    selected: list[bool]
    completion_day: list[int]
    sessions: list[Session] = field(default_factory=list)
    planned_topics: int = 0
    study_units: int = 0
    review_units: int = 0
    total_units: int = 0

    def add_session(self, day: int, topic: int, units: int, review: bool = False) -> None:
        if units <= 0:
            return
        self.sessions.append(Session(day, topic, units, review))
        if review:
            self.review_units += units
        else:
            self.study_units += units
        self.total_units += units


@dataclass
class Simulation:
    mastery: list[float]
    stability: list[float]
    weighted_score: float
    assessment_scores: list[float]
    study_units: int
    review_units: int
    skipped_units: int
    day_log: str


# ---------------------------------------------------------------------------
# Built-in sample. This is the same compact sample embedded in the C edition.


def builtin_dataset() -> Dataset:
    topics = [
        Topic(0, "Foundations", 4, 2, 50, 0.00),
        Topic(1, "Topic1", 4, 3, 17, 0.78),
        Topic(2, "Topic2", 2, 2, 59, 0.84),
        Topic(3, "Topic3", 5, 4, 76, 0.74),
        Topic(4, "Topic4", 8, 8, 47, 0.02),
        Topic(5, "Topic5", 7, 4, 39, 0.17),
        Topic(6, "Topic6", 6, 3, 13, 0.20),
        Topic(7, "Topic7", 9, 3, 42, 0.02),
        Topic(8, "Topic8", 7, 2, 66, 0.07),
        Topic(9, "Topic9", 5, 9, 41, 0.05),
        Topic(10, "Topic10", 3, 2, 63, 0.24),
        Topic(11, "Topic11", 8, 6, 86, 0.27),
    ]
    prereqs = [
        (0, 1), (0, 2), (0, 3), (1, 4), (0, 4), (0, 5), (4, 6),
        (5, 6), (3, 7), (6, 7), (4, 8), (7, 9), (9, 10), (0, 11), (7, 11),
    ]
    related = [
        (1, 0, 6), (2, 0, 6), (3, 2, 6), (4, 0, 3), (5, 3, 8),
        (6, 5, 5), (7, 2, 4), (8, 3, 12), (9, 4, 8), (10, 0, 3),
        (11, 1, 5), (1, 6, 7), (5, 3, 11), (3, 0, 9), (9, 7, 4),
        (4, 3, 9), (6, 7, 10), (2, 7, 2), (9, 11, 7), (7, 2, 2),
        (9, 0, 1), (5, 6, 12),
    ]
    assessments = [
        Assessment(0, "Exam0", 16470, 16530, 0.21, 0, [1, 3, 7, 9]),
        Assessment(1, "Exam1", 15030, 15120, 0.26, 0, [2, 9, 11]),
    ]
    mentors = [
        (0, "Mentor0", [4, 8]),
        (1, "Mentor1", [4, 6, 8, 10]),
        (2, "Mentor2", [1, 5, 8, 11]),
    ]
    return Dataset(topics, prereqs, related, assessments, mentors, Config())


# ---------------------------------------------------------------------------
# Dataset loading and validation


def _read_csv(path: Path) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            return list(csv.DictReader(handle))
    except OSError as exc:
        raise ValueError(f"cannot open {path}: {exc}") from exc


def _int(value: str, label: str) -> int:
    try:
        return int(value.strip())
    except (AttributeError, ValueError) as exc:
        raise ValueError(f"{label}: expected an integer, got {value!r}") from exc


def _float(value: str, label: str) -> float:
    try:
        number = float(value.strip())
    except (AttributeError, ValueError) as exc:
        raise ValueError(f"{label}: expected a number, got {value!r}") from exc
    if not math.isfinite(number):
        raise ValueError(f"{label}: value must be finite")
    return number


def _int_list(value: str, label: str) -> list[int]:
    if not value.strip():
        return []
    try:
        return [int(part.strip()) for part in value.split(";")]
    except ValueError as exc:
        raise ValueError(f"{label}: expected semicolon-separated integers") from exc


def load_dataset(directory: str) -> Dataset:
    if directory.lower() in {"builtin", "sample"}:
        return builtin_dataset()

    folder = Path(directory)
    if not folder.is_dir():
        raise ValueError(f"dataset directory does not exist: {folder}")

    ds = Dataset()
    for row_no, row in enumerate(_read_csv(folder / "topics.csv"), start=2):
        ds.topics.append(Topic(
            _int(row.get("id", ""), f"topics.csv:{row_no}:id"),
            row.get("name", "").strip(),
            _int(row.get("units", ""), f"topics.csv:{row_no}:units"),
            _int(row.get("difficulty", ""), f"topics.csv:{row_no}:difficulty"),
            _float(row.get("value", ""), f"topics.csv:{row_no}:value"),
            _float(row.get("mastery", ""), f"topics.csv:{row_no}:mastery"),
        ))

    for row_no, row in enumerate(_read_csv(folder / "prereqs.csv"), start=2):
        ds.prereqs.append((
            _int(row.get("prereq", ""), f"prereqs.csv:{row_no}:prereq"),
            _int(row.get("topic", ""), f"prereqs.csv:{row_no}:topic"),
        ))

    related_file = folder / "related.csv"
    if related_file.exists():
        for row_no, row in enumerate(_read_csv(related_file), start=2):
            ds.related.append((
                _int(row.get("a", ""), f"related.csv:{row_no}:a"),
                _int(row.get("b", ""), f"related.csv:{row_no}:b"),
                _int(row.get("effort", ""), f"related.csv:{row_no}:effort"),
            ))

    for row_no, row in enumerate(_read_csv(folder / "assessments.csv"), start=2):
        ds.assessments.append(Assessment(
            _int(row.get("id", ""), f"assessments.csv:{row_no}:id"),
            row.get("name", "").strip(),
            _int(row.get("start", ""), f"assessments.csv:{row_no}:start"),
            _int(row.get("end", ""), f"assessments.csv:{row_no}:end"),
            _float(row.get("weight", ""), f"assessments.csv:{row_no}:weight"),
            _int(row.get("optional", ""), f"assessments.csv:{row_no}:optional"),
            _int_list(row.get("topics", ""), f"assessments.csv:{row_no}:topics"),
        ))

    mentors_file = folder / "mentors.csv"
    if mentors_file.exists():
        for row_no, row in enumerate(_read_csv(mentors_file), start=2):
            ds.mentors.append((
                _int(row.get("id", ""), f"mentors.csv:{row_no}:id"),
                row.get("name", "").strip(),
                _int_list(row.get("skills", ""), f"mentors.csv:{row_no}:skills"),
            ))

    config_file = folder / "config.cfg"
    if config_file.exists():
        values: dict[str, str] = {}
        with config_file.open("r", encoding="utf-8-sig") as handle:
            for line_no, raw in enumerate(handle, start=1):
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    raise ValueError(f"config.cfg:{line_no}: expected key=value")
                key, value = (part.strip() for part in line.split("=", 1))
                values[key] = value
        supported = {
            "kind", "days", "units_per_day", "hard_units_per_day", "hard_threshold",
            "buffer", "review_reserve", "mastery_threshold", "review_gaps", "missed_days",
        }
        unknown = sorted(set(values) - supported)
        if unknown:
            raise ValueError(f"config.cfg: unknown key(s): {', '.join(unknown)}")
        try:
            for key in ("kind",):
                if key in values:
                    setattr(ds.cfg, key, values[key])
            for key in ("days", "units_per_day", "hard_units_per_day", "hard_threshold"):
                if key in values:
                    setattr(ds.cfg, key, int(values[key]))
            for key in ("buffer", "review_reserve", "mastery_threshold"):
                if key in values:
                    setattr(ds.cfg, key, float(values[key]))
            if "review_gaps" in values:
                ds.cfg.review_gaps = _int_list(values["review_gaps"], "config.cfg:review_gaps")
            if "missed_days" in values:
                ds.cfg.missed_days = _int_list(values["missed_days"], "config.cfg:missed_days")
        except ValueError as exc:
            raise ValueError(f"config.cfg: invalid value: {exc}") from exc

    validate_dataset(ds)
    return ds


def topological_order(ds: Dataset) -> list[int]:
    n = len(ds.topics)
    indegree = [0] * n
    outgoing: list[list[int]] = [[] for _ in range(n)]
    for prereq, topic in ds.prereqs:
        indegree[topic] += 1
        outgoing[prereq].append(topic)
    queue = deque(i for i, degree in enumerate(indegree) if degree == 0)
    order: list[int] = []
    while queue:
        node = queue.popleft()
        order.append(node)
        for nxt in outgoing[node]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)
    if len(order) != n:
        raise ValueError("prerequisite graph contains a cycle")
    return order


def validate_dataset(ds: Dataset) -> None:
    n = len(ds.topics)
    if n == 0:
        raise ValueError("dataset contains no topics")
    if not 1 <= ds.cfg.days <= 100000:
        raise ValueError("days must be between 1 and 100000")
    if not 1 <= ds.cfg.units_per_day <= 48:
        raise ValueError("units_per_day must be between 1 and 48")
    if not 0 <= ds.cfg.hard_units_per_day <= ds.cfg.units_per_day:
        raise ValueError("hard_units_per_day is outside the daily capacity")
    if not 1 <= ds.cfg.hard_threshold <= 10:
        raise ValueError("hard_threshold must be between 1 and 10")
    if not 1.0 <= ds.cfg.buffer <= 5.0:
        raise ValueError("buffer must be between 1 and 5")
    if not 0.0 <= ds.cfg.review_reserve < 0.8:
        raise ValueError("review_reserve must be between 0 and 0.8")
    if not 0.0 <= ds.cfg.mastery_threshold <= 1.0:
        raise ValueError("mastery_threshold must be between 0 and 1")
    if n > 200000:
        raise ValueError("too many topics (maximum 200000)")

    for expected, topic in enumerate(ds.topics):
        if topic.id != expected:
            raise ValueError(f"topic IDs must be contiguous and start at 0 (expected ID {expected})")
        if not topic.name:
            raise ValueError(f"topic {topic.id} has an empty name")
        if not 1 <= topic.units <= 1_000_000:
            raise ValueError(f"topic {topic.id} units must be between 1 and 1000000")
        if not 1 <= topic.difficulty <= 10:
            raise ValueError(f"topic {topic.id} difficulty must be between 1 and 10")
        if not 0 <= topic.value <= 100:
            raise ValueError(f"topic {topic.id} value must be between 0 and 100")
        if not 0 <= topic.mastery <= 1:
            raise ValueError(f"topic {topic.id} mastery must be between 0 and 1")

    for row_no, (prereq, topic) in enumerate(ds.prereqs, start=2):
        if not (0 <= prereq < n and 0 <= topic < n) or prereq == topic:
            raise ValueError(f"prerequisite row {row_no} references an invalid topic")
    for row_no, (a, b, effort) in enumerate(ds.related, start=2):
        if not (0 <= a < n and 0 <= b < n) or a == b or effort < 0:
            raise ValueError(f"related-topic row {row_no} is invalid")
    for assessment in ds.assessments:
        if (assessment.start < 0 or assessment.end <= assessment.start or
                not 0 <= assessment.weight <= 1 or assessment.optional not in (0, 1)):
            raise ValueError(f"assessment {assessment.id} has an invalid time, weight, or optional flag")
        for topic_id in assessment.topics:
            if not 0 <= topic_id < n:
                raise ValueError(f"assessment {assessment.id} references unknown topic {topic_id}")
    for mentor_id, _name, skills in ds.mentors:
        for topic_id in skills:
            if not 0 <= topic_id < n:
                raise ValueError(f"mentor {mentor_id} references unknown topic {topic_id}")
    for day in ds.cfg.missed_days:
        if not 0 <= day < ds.cfg.days:
            raise ValueError("missed_days contains a day outside the planning horizon")
    topological_order(ds)


# ---------------------------------------------------------------------------
# Planner algorithms


def day_capacity(ds: Dataset) -> int:
    return max(1, math.floor(ds.cfg.units_per_day * (1.0 - ds.cfg.review_reserve) + 1e-9))


def topic_deadlines(ds: Dataset) -> tuple[list[int], list[float]]:
    n = len(ds.topics)
    deadlines = [ds.cfg.days - 1] * n
    weights = [0.05] * n
    for assessment in ds.assessments:
        last_study_day = assessment.start // 1440 - 1
        last_study_day = min(last_study_day, ds.cfg.days - 1)
        for topic_id in assessment.topics:
            deadlines[topic_id] = min(deadlines[topic_id], last_study_day)
            weights[topic_id] += assessment.weight
    return deadlines, [min(weight, 1.0) for weight in weights]


def topic_urgent(ds: Dataset, deadline: int) -> bool:
    window = min(4, max(2, ds.cfg.days // 3))
    return deadline <= window


def topic_quadrant(ds: Dataset, topic: Topic, deadline: int) -> int:
    important = topic.value >= 50.0
    urgent = topic_urgent(ds, deadline)
    if important and urgent:
        return 1  # DO
    if important:
        return 2  # DECIDE
    if urgent:
        return 3  # DELEGATE
    return 4      # DELETE


def topic_priority(topic: Topic, deadline: int, weight: float) -> float:
    days_left = max(1, deadline + 1)
    urgency = 1.0 + 3.0 / days_left
    priority = (topic.value + 1.0) * (1.0 - topic.mastery) * (0.35 + 2.0 * weight)
    priority *= 1.0 + (topic.difficulty - 1) * 0.025
    return priority * urgency


def _selection_fits(
    ds: Dataset, selected: list[bool], deadlines: list[int], costs: list[int],
    hard: list[bool], additions: list[bool],
) -> bool:
    daily = day_capacity(ds)
    selected_by_deadline = [0] * ds.cfg.days
    hard_by_deadline = [0] * ds.cfg.days
    total = total_hard = 0
    for i in range(len(ds.topics)):
        if selected[i] or additions[i]:
            day = deadlines[i]
            if day < 0:
                return False
            day = min(day, ds.cfg.days - 1)
            selected_by_deadline[day] += costs[i]
            total += costs[i]
            if hard[i]:
                hard_by_deadline[day] += costs[i]
                total_hard += costs[i]
    capacity_prefix = 0
    hard_capacity_prefix = 0
    required_prefix = 0
    hard_required_prefix = 0
    missed = set(ds.cfg.missed_days)
    for day in range(ds.cfg.days):
        if day not in missed:
            capacity_prefix += daily
            hard_capacity_prefix += ds.cfg.hard_units_per_day
        required_prefix += selected_by_deadline[day]
        hard_required_prefix += hard_by_deadline[day]
        if required_prefix > capacity_prefix or hard_required_prefix > hard_capacity_prefix:
            return False
    return total <= ds.cfg.days * daily and total_hard <= ds.cfg.days * ds.cfg.hard_units_per_day


def _mark_ancestors(ds: Dataset, topic: int, mastered: list[bool]) -> list[bool]:
    needed = [False] * len(ds.topics)
    needed[topic] = True
    changed = True
    while changed:
        changed = False
        for prereq, dependent in ds.prereqs:
            if needed[dependent] and not mastered[prereq] and not needed[prereq]:
                needed[prereq] = True
                changed = True
    return needed


def _try_select(
    ds: Dataset, candidate: int, mastered: list[bool], order: list[int],
    deadlines: list[int], costs: list[int], hard: list[bool], selected: list[bool],
    use_matrix: bool,
) -> bool:
    needed = _mark_ancestors(ds, candidate, mastered)
    for topic_id in order:
        if needed[topic_id] and not selected[topic_id] and not mastered[topic_id]:
            if deadlines[topic_id] < 0:
                return False
            if (use_matrix and topic_id == candidate and
                    topic_quadrant(ds, ds.topics[topic_id], deadlines[topic_id]) == 4):
                return False
    if not _selection_fits(ds, selected, deadlines, costs, hard, needed):
        return False
    for topic_id in order:
        if needed[topic_id] and not mastered[topic_id]:
            selected[topic_id] = True
    return True


def build_plan(ds: Dataset, strategy: str = "greedy", use_matrix: bool = False) -> Plan:
    if strategy not in {"baseline", "greedy"}:
        raise ValueError("strategy must be 'baseline' or 'greedy'")
    order = topological_order(ds)
    deadlines, weights = topic_deadlines(ds)
    n = len(ds.topics)
    mastered = [topic.mastery >= ds.cfg.mastery_threshold for topic in ds.topics]
    costs = [max(1, math.ceil(topic.units * ds.cfg.buffer - 1e-9)) for topic in ds.topics]
    hard = [topic.difficulty >= ds.cfg.hard_threshold for topic in ds.topics]
    scores = [0.0] * n
    candidates = []

    for i, topic in enumerate(ds.topics):
        if not mastered[i]:
            scores[i] = topic_priority(topic, deadlines[i], weights[i])
            if use_matrix:
                quadrant = topic_quadrant(ds, topic, deadlines[i])
                if quadrant == 1:
                    scores[i] *= 1.35
                elif quadrant == 3:
                    scores[i] *= 0.80
                elif quadrant == 4:
                    scores[i] *= 0.20
            candidates.append(i)

    if strategy == "baseline":
        candidates = [topic_id for topic_id in order if not mastered[topic_id]]
    else:
        candidates.sort(key=lambda topic_id: (-scores[topic_id], topic_id))

    selected = [False] * n
    for topic_id in candidates:
        if selected[topic_id] or mastered[topic_id]:
            continue
        if use_matrix and topic_quadrant(ds, ds.topics[topic_id], deadlines[topic_id]) == 4:
            continue
        _try_select(ds, topic_id, mastered, order, deadlines, costs, hard, selected, use_matrix)

    plan = Plan(strategy, selected, [-1] * n)
    remaining = [costs[i] if selected[i] else 0 for i in range(n)]
    used_by_day = [0] * ds.cfg.days
    missed = set(ds.cfg.missed_days)
    daily = day_capacity(ds)

    # Day-by-day list scheduling. A dependent topic starts only after its
    # non-mastered prerequisites have been completed on an earlier day.
    for day in range(ds.cfg.days):
        free_units = 0 if day in missed else daily
        hard_left = 0 if day in missed else ds.cfg.hard_units_per_day
        while free_units > 0:
            best = -1
            best_score = -1.0
            for topic_id in range(n):
                if not selected[topic_id] or remaining[topic_id] <= 0 or deadlines[topic_id] < day:
                    continue
                ready = True
                for prereq, dependent in ds.prereqs:
                    if dependent == topic_id and not mastered[prereq]:
                        completion = plan.completion_day[prereq]
                        if completion < 0 or completion >= day:
                            ready = False
                            break
                if not ready or (hard[topic_id] and hard_left <= 0):
                    continue
                if (best < 0 or deadlines[topic_id] < deadlines[best] or
                        (deadlines[topic_id] == deadlines[best] and scores[topic_id] > best_score)):
                    best = topic_id
                    best_score = scores[topic_id]
            if best < 0:
                break
            take = min(remaining[best], free_units)
            if hard[best]:
                take = min(take, hard_left)
            if take < 1:
                break
            plan.add_session(day, best, take, False)
            remaining[best] -= take
            free_units -= take
            if hard[best]:
                hard_left -= take
            used_by_day[day] += take
            if remaining[best] == 0:
                plan.completion_day[best] = day

    # Remove topics that could not be completed before their own deadline.
    for topic_id in order:
        invalid = (selected[topic_id] and
                   (remaining[topic_id] > 0 or plan.completion_day[topic_id] < 0 or
                    plan.completion_day[topic_id] > deadlines[topic_id]))
        if invalid:
            selected[topic_id] = False
        if selected[topic_id]:
            for prereq, dependent in ds.prereqs:
                if dependent == topic_id and not mastered[prereq] and not selected[prereq]:
                    selected[topic_id] = False
                    break

    # Remove study sessions for topics removed by cleanup.
    kept_sessions: list[Session] = []
    plan.study_units = 0
    plan.total_units = plan.review_units
    for session in plan.sessions:
        if session.review or selected[session.topic]:
            kept_sessions.append(session)
            if not session.review:
                plan.study_units += session.units
                plan.total_units += session.units
        else:
            used_by_day[session.day] -= session.units
    plan.sessions = kept_sessions

    # Spaced review sessions use the capacity reserved from daily study work.
    for topic_id in range(n):
        if selected[topic_id] and plan.completion_day[topic_id] >= 0:
            for gap in ds.cfg.review_gaps:
                day = plan.completion_day[topic_id] + gap
                if day >= ds.cfg.days or day in missed:
                    continue
                if used_by_day[day] < ds.cfg.units_per_day:
                    plan.add_session(day, topic_id, 1, True)
                    used_by_day[day] += 1

    plan.planned_topics = sum(selected)
    return plan


# ---------------------------------------------------------------------------
# Retention and assessment simulation

COMPLETION_GAIN = 0.85
BASE_STABILITY = 3.0
KNOWN_STABILITY = 10.0
STUDY_STABILITY_MULT = 1.5
REVIEW_STABILITY_MULT = 2.0
REVIEW_GAIN = 0.15
FATIGUE_FREE_UNITS = 6
FATIGUE_FACTOR = 0.75


def _retention(stability: float, days: int) -> float:
    if days <= 0:
        return 1.0
    return math.exp(-days / max(stability, 0.1))


def _effective_mastery(mastery: float, stability: float, last_day: int, day: int) -> float:
    return mastery * _retention(stability, day - last_day)


def simulate(ds: Dataset, plan: Plan, extra_missed: Optional[Iterable[int]] = None) -> Simulation:
    extra = set(extra_missed or [])
    if any(day < 0 or day >= ds.cfg.days for day in extra):
        raise ValueError("a missed day is outside the planning horizon")
    missed = set(ds.cfg.missed_days) | extra
    n = len(ds.topics)
    progress = [0.0] * n
    stored = [topic.mastery for topic in ds.topics]
    stability = [BASE_STABILITY + (KNOWN_STABILITY - BASE_STABILITY) * topic.mastery
                 for topic in ds.topics]
    last = [0] * n
    completed = [topic.mastery >= ds.cfg.mastery_threshold for topic in ds.topics]
    executed_study = executed_review = skipped = 0
    day_symbols: list[str] = []
    sessions_by_day: list[list[Session]] = [[] for _ in range(ds.cfg.days)]
    for session in plan.sessions:
        sessions_by_day[session.day].append(session)

    for day in range(ds.cfg.days):
        if day in missed:
            day_symbols.append("M")
            skipped += sum(session.units for session in sessions_by_day[day])
            continue
        any_study = any_review = False
        total_today = 0
        for session in sessions_by_day[day]:
            topic_id = session.topic
            if session.review:
                current = _effective_mastery(stored[topic_id], stability[topic_id], last[topic_id], day)
                stored[topic_id] = current + (1.0 - current) * REVIEW_GAIN
                stability[topic_id] *= REVIEW_STABILITY_MULT
                last[topic_id] = day
                executed_review += session.units
                any_review = True
            else:
                effective_units = sum(
                    1.0 if total_today + unit_index < FATIGUE_FREE_UNITS else FATIGUE_FACTOR
                    for unit_index in range(session.units)
                )
                current = _effective_mastery(stored[topic_id], stability[topic_id], last[topic_id], day)
                close = 1.0 - (1.0 - COMPLETION_GAIN) ** (effective_units / ds.topics[topic_id].units)
                stored[topic_id] = current + (1.0 - current) * close
                last[topic_id] = day
                progress[topic_id] += effective_units
                if not completed[topic_id] and progress[topic_id] >= ds.topics[topic_id].units:
                    completed[topic_id] = True
                    stability[topic_id] *= STUDY_STABILITY_MULT
                total_today += session.units
                executed_study += session.units
                any_study = True
        day_symbols.append("B" if any_study and any_review else "S" if any_study else "R" if any_review else ".")

    final_mastery = [
        _effective_mastery(stored[i], stability[i], last[i], ds.cfg.days - 1)
        for i in range(n)
    ]
    assessment_scores: list[float] = []
    weighted_sum = weight_total = 0.0
    if ds.assessments:
        for assessment in ds.assessments:
            exam_day = assessment.start // 1440
            score = (sum(_effective_mastery(stored[t], stability[t], last[t], exam_day)
                         for t in assessment.topics) / len(assessment.topics)
                     if assessment.topics else 0.0)
            assessment_scores.append(score)
            weighted_sum += score * assessment.weight
            weight_total += assessment.weight
        weighted_score = weighted_sum / weight_total if weight_total > 0 else 0.0
    else:
        weighted_score = sum(final_mastery) / n if n else 0.0

    return Simulation(final_mastery, stability, weighted_score, assessment_scores,
                      executed_study, executed_review, skipped, "".join(day_symbols))


# ---------------------------------------------------------------------------
# Output, reports and exports


def print_dataset_summary(ds: Dataset) -> None:
    print("Dataset summary")
    print(f"  Topics: {len(ds.topics)} | Prerequisites: {len(ds.prereqs)} | "
          f"Assessments: {len(ds.assessments)} | Mentors: {len(ds.mentors)}")
    print(f"  Horizon: {ds.cfg.days} days | Daily capacity: {ds.cfg.units_per_day} units "
          f"({ds.cfg.units_per_day * 0.5:.1f} hours) | Hard-topic limit: {ds.cfg.hard_units_per_day} units/day")
    print(f"  Study capacity after review reserve: {day_capacity(ds)} units/day")


def print_plan(ds: Dataset, plan: Plan, max_sessions: int = 40) -> None:
    print(f"Plan strategy: {plan.strategy}" + (" (no topics fit)" if plan.planned_topics == 0 else ""))
    print(f"Selected topics: {plan.planned_topics} | Study units: {plan.study_units} | "
          f"Review units: {plan.review_units} | Total: {plan.total_units} units "
          f"({plan.total_units * 0.5:.1f} hours)")

    per_day_study = [0] * ds.cfg.days
    per_day_review = [0] * ds.cfg.days
    for session in plan.sessions:
        (per_day_review if session.review else per_day_study)[session.day] += session.units

    print("\nDay-by-day agenda")
    missed = set(ds.cfg.missed_days)
    for day in range(ds.cfg.days):
        study, review = per_day_study[day], per_day_review[day]
        if study + review or day in missed:
            if day in missed:
                print(f"  Day {day:2d}: MISSED")
            else:
                print(f"  Day {day:2d}: {study} study + {review} review unit(s)")

    print("\nSessions")
    shown = 0
    for session in plan.sessions:
        if max_sessions >= 0 and shown >= max_sessions:
            break
        kind = "Review" if session.review else "Study"
        print(f"  Day {session.day:2d} | {kind:<6} | {session.units:2d} unit(s) | {ds.topics[session.topic].name}")
        shown += 1
    if shown < len(plan.sessions):
        print(f"  ... {len(plan.sessions) - shown} more session(s) not shown")

    print("\nTopics selected")
    for topic_id, is_selected in enumerate(plan.selected):
        if is_selected:
            print(f"  [{topic_id:2d}] {ds.topics[topic_id].name:<34} complete by day {plan.completion_day[topic_id]}")


def print_simulation(ds: Dataset, sim: Simulation) -> None:
    print("\nLearning simulation")
    print(f"  Day log: {sim.day_log}  (S=study, R=review, B=both, M=missed, .=idle)")
    print(f"  Executed: {sim.study_units} study + {sim.review_units} review units; skipped: {sim.skipped_units} units")
    if ds.assessments:
        for assessment, score in zip(ds.assessments, sim.assessment_scores):
            print(f"  {assessment.name:<30} expected mastery: {score * 100:5.1f}%")
        print(f"  Weighted expected assessment score: {sim.weighted_score * 100:.1f}%")
    else:
        print(f"  Average retained mastery at horizon end: {sim.weighted_score * 100:.1f}%")


def print_matrix(ds: Dataset, show_all: bool = False) -> None:
    deadlines, _weights = topic_deadlines(ds)
    labels = {1: "DO", 2: "DECIDE", 3: "DELEGATE", 4: "DELETE"}
    print("Eisenhower matrix (importance threshold: 50/100; urgent: within roughly one-third of the horizon)")
    for quadrant in range(1, 5):
        print(f"\n{labels[quadrant]}")
        for topic, deadline in zip(ds.topics, deadlines):
            if topic_quadrant(ds, topic, deadline) == quadrant and (show_all or topic.mastery < ds.cfg.mastery_threshold):
                print(f"  [{topic.id:2d}] {topic.name:<36} importance {topic.value:5.1f} | deadline day {deadline}")


def export_csv(path: str, ds: Dataset, plan: Plan) -> None:
    with open(path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["day", "topic_id", "topic", "session_type", "units"])
        for session in plan.sessions:
            writer.writerow([session.day, session.topic, ds.topics[session.topic].name,
                             "review" if session.review else "study", session.units])


def export_json(path: str, ds: Dataset, plan: Plan, sim: Simulation) -> None:
    payload = {
        "strategy": plan.strategy,
        "planned_topics": plan.planned_topics,
        "study_units": plan.study_units,
        "review_units": plan.review_units,
        "total_units": plan.total_units,
        "sessions": [
            {"day": s.day, "topic_id": s.topic, "topic": ds.topics[s.topic].name,
             "type": "review" if s.review else "study", "units": s.units}
            for s in plan.sessions
        ],
        "weighted_exam_score": sim.weighted_score,
        "simulated_study_units": sim.study_units,
        "simulated_review_units": sim.review_units,
        "skipped_units": sim.skipped_units,
        "day_log": sim.day_log,
        "assessment_scores": [
            {"assessment": a.name, "expected_mastery": score}
            for a, score in zip(ds.assessments, sim.assessment_scores)
        ],
    }
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


# ---------------------------------------------------------------------------
# CLI, strategy comparison and interactive menu


def command_validate(directory: str) -> int:
    ds = load_dataset(directory)
    print("dataset OK")
    print_dataset_summary(ds)
    return 0


def command_plan(args: argparse.Namespace, simulation_only: bool = False) -> int:
    ds = load_dataset(args.dataset)
    missed = []
    if args.missed:
        try:
            missed = [int(part.strip()) for part in args.missed.split(",") if part.strip()]
        except ValueError as exc:
            raise ValueError("--missed must be a comma-separated list such as 2,3,4") from exc
        if any(day < 0 or day >= ds.cfg.days for day in missed):
            raise ValueError(f"missed day must be between 0 and {ds.cfg.days - 1}")
    plan = build_plan(ds, args.strategy, args.matrix)
    sim = simulate(ds, plan, missed)
    print_dataset_summary(ds)
    print()
    print_plan(ds, plan, 0 if simulation_only else args.lines)
    print_simulation(ds, sim)
    if missed:
        print(f"\nAdditional missed days simulated: {len(set(missed))}")
    if args.matrix:
        print("\nEisenhower matrix was applied to topic selection.")
    if args.csv:
        export_csv(args.csv, ds, plan)
        print(f"\nWrote CSV: {args.csv}")
    if args.json:
        export_json(args.json, ds, plan, sim)
        print(f"Wrote JSON: {args.json}")
    return 0


def command_compare(directory: str, use_matrix: bool = False) -> int:
    ds = load_dataset(directory)
    baseline = build_plan(ds, "baseline", use_matrix)
    greedy = build_plan(ds, "greedy", use_matrix)
    sim_baseline = simulate(ds, baseline)
    sim_greedy = simulate(ds, greedy)
    print_dataset_summary(ds)
    print("\nStrategy comparison" + (" (Eisenhower enabled)" if use_matrix else ""))
    print(f"  {'Strategy':<12} | {'Topics':>7} | {'Study units':>11} | {'Review':>8} | {'Exam score':>10}")
    print(f"  {'-' * 12}-+-{'-' * 7}-+-{'-' * 11}-+-{'-' * 8}-+-{'-' * 10}")
    for name, plan, sim in (("baseline", baseline, sim_baseline), ("greedy", greedy, sim_greedy)):
        print(f"  {name:<12} | {plan.planned_topics:7d} | {plan.study_units:11d} | "
              f"{plan.review_units:8d} | {sim.weighted_score * 100:9.1f}%")
    return 0


def command_algorithms() -> None:
    print("Python edition: algorithm concepts used by the planner\n")
    print("  1. Directed graphs / topological sorting: Kahn's algorithm checks prerequisite order.")
    print("  2. Greedy optimisation: ranks topics by value, mastery gap, urgency and study cost.")
    print("  3. Feasibility checks: prefix-capacity tests respect deadlines and hard-topic limits.")
    print("  4. Scheduling: day-by-day list scheduling starts a topic after its prerequisites.")
    print("  5. Simulation: exponential memory decay, spaced review and diminishing study returns.")
    print("  6. Eisenhower matrix: classifies tasks as Do / Decide / Delegate / Delete.")
    print("\nThis compact edition provides baseline and greedy strategies; it does not include")
    print("the original C++ DP/branch-and-bound suite or graphical Priority Studio interface.")


def interactive_menu() -> int:
    while True:
        print("\nPERSONALIZED LEARNING PLANNER - Python edition")
        print("1. Validate built-in sample dataset")
        print("2. Generate a study plan")
        print("3. Show Eisenhower priority matrix")
        print("4. Compare planning strategies")
        print("5. Exit")
        try:
            choice = input("Choose an option: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        try:
            if choice == "1":
                command_validate("builtin")
            elif choice == "2":
                ds = builtin_dataset()
                plan = build_plan(ds, "greedy")
                sim = simulate(ds, plan)
                print_dataset_summary(ds)
                print()
                print_plan(ds, plan)
                print_simulation(ds, sim)
            elif choice == "3":
                print_matrix(builtin_dataset(), True)
            elif choice == "4":
                command_compare("builtin")
            elif choice == "5":
                return 0
            else:
                print("Please enter a number from 1 to 5.")
        except (ValueError, OSError) as exc:
            print(f"error: {exc}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="learning_planner.py",
        description="Personalized Learning Path and Assessment Planner (Python single-file edition)",
        epilog="One unit = 30 minutes. Dataset defaults to the built-in sample.",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("menu", help="open the interactive terminal menu")

    validate_parser = sub.add_parser("validate", help="validate a dataset and show a summary")
    validate_parser.add_argument("dataset", nargs="?", default="builtin")

    for command, help_text in (("plan", "build a plan and simulate expected assessment recall"),
                               ("simulate", "run the planning and memory simulation pipeline")):
        plan_parser = sub.add_parser(command, help=help_text)
        plan_parser.add_argument("dataset", nargs="?", default="builtin")
        plan_parser.add_argument("--strategy", choices=("baseline", "greedy"), default="greedy")
        plan_parser.add_argument("--matrix", action="store_true", help="apply Eisenhower priorities")
        plan_parser.add_argument("--missed", default="", help="additional missed day numbers, e.g. 2,3")
        plan_parser.add_argument("--csv", help="export sessions to a CSV file")
        plan_parser.add_argument("--json", help="export plan and simulation to a JSON file")
        plan_parser.add_argument("--lines", type=int, default=40, help="maximum sessions to print")

    compare_parser = sub.add_parser("compare", help="compare baseline and greedy strategies")
    compare_parser.add_argument("dataset", nargs="?", default="builtin")
    compare_parser.add_argument("--matrix", action="store_true")

    matrix_parser = sub.add_parser("matrix", help="show the Eisenhower priority matrix")
    matrix_parser.add_argument("dataset", nargs="?", default="builtin")
    matrix_parser.add_argument("--all", action="store_true", help="include already-mastered topics")

    sub.add_parser("algorithms", help="explain the algorithms used")
    sub.add_parser("demo", help="run a plan on the built-in sample")
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command is None or args.command == "menu":
        return interactive_menu()
    try:
        if args.command == "validate":
            return command_validate(args.dataset)
        if args.command in {"plan", "simulate"}:
            if args.lines < 0:
                raise ValueError("--lines must be zero or greater")
            return command_plan(args, args.command == "simulate")
        if args.command == "compare":
            return command_compare(args.dataset, args.matrix)
        if args.command == "matrix":
            ds = load_dataset(args.dataset)
            print_matrix(ds, args.all)
            return 0
        if args.command == "algorithms":
            command_algorithms()
            return 0
        if args.command == "demo":
            ds = builtin_dataset()
            plan = build_plan(ds, "greedy", True)
            sim = simulate(ds, plan)
            print_dataset_summary(ds)
            print()
            print_plan(ds, plan)
            print_simulation(ds, sim)
            return 0
        parser.print_help()
        return 0
    except (ValueError, OSError, csv.Error) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
