# Personalized Learning Planner — Codespaces browser GUI

## Run in GitHub Codespaces

1. Upload `app.py`, `learning_planner.py`, and `requirements.txt` to the root of your GitHub repository.
2. In GitHub, open **Code → Codespaces → Create codespace**.
3. In the Codespaces terminal, run:

   ```bash
   pip install -r requirements.txt
   streamlit run app.py --server.address 0.0.0.0
   ```

4. When Codespaces shows that port **8501** is available, choose **Open in Browser** (or open the **Ports** tab and click the globe icon for port 8501).
5. Use the planner in the browser. The built-in sample dataset is selected automatically.

No MinGW or Windows compiler is needed. This browser GUI uses the Python planner implementation. It is not a browser port of the Win32 C source.
