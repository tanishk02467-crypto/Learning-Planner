import contextlib
import io
import tempfile
from pathlib import Path
import streamlit as st
import learning_planner as planner

st.set_page_config(page_title="Personalized Learning Planner", page_icon="📚", layout="wide")
st.title("📚 Personalized Learning Planner")
st.caption("Browser-based interface powered by the existing Python planner algorithms.")

with st.sidebar:
    st.header("Plan settings")
    strategy = st.selectbox("Planning strategy", ["greedy", "baseline"])
    use_matrix = st.checkbox("Apply Eisenhower priority matrix", value=False)
    show_lines = st.slider("Maximum sessions to display", 10, 200, 40, 10)
    missed_text = st.text_input("Missed study days (optional)", placeholder="e.g. 2,3")
    st.caption("Using the built-in sample dataset. No upload is required.")

def capture(func, *args, **kwargs):
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        func(*args, **kwargs)
    return buffer.getvalue()

try:
    ds = planner.builtin_dataset()
    c1, c2, c3 = st.columns(3)
    c1.metric("Topics", len(ds.topics))
    c2.metric("Planning horizon", f"{ds.cfg.days} days")
    c3.metric("Daily capacity", f"{ds.cfg.units_per_day * 0.5:g} hours")
except Exception as exc:
    st.error(f"Could not load the built-in dataset: {exc}")
    st.stop()

tabs = st.tabs(["Generate plan", "Compare strategies", "Priority matrix", "Validate dataset", "About"])
with tabs[0]:
    st.subheader("Generate your study plan")
    if st.button("Generate plan", type="primary"):
        try:
            missed = [int(x.strip()) for x in missed_text.split(",") if x.strip()]
            if any(x < 0 or x >= ds.cfg.days for x in missed):
                st.error(f"Missed days must be between 0 and {ds.cfg.days - 1}.")
            else:
                plan = planner.build_plan(ds, strategy, use_matrix)
                sim = planner.simulate(ds, plan, missed)
                st.success("Plan generated successfully")
                st.write({"Planned topics": plan.planned_topics, "Study units": plan.study_units,
                          "Review units": plan.review_units, "Expected weighted assessment score": f"{sim.weighted_score * 100:.1f}%"})
                output = capture(planner.print_plan, ds, plan, show_lines) + "\n" + capture(planner.print_simulation, ds, sim)
                st.text_area("Plan details", output, height=360)
                with tempfile.TemporaryDirectory() as tmp:
                    csv_path = Path(tmp) / "learning_plan.csv"
                    json_path = Path(tmp) / "learning_plan.json"
                    planner.export_csv(str(csv_path), ds, plan)
                    planner.export_json(str(json_path), ds, plan, sim)
                    st.download_button("Download CSV", csv_path.read_bytes(), "learning_plan.csv", "text/csv")
                    st.download_button("Download JSON", json_path.read_bytes(), "learning_plan.json", "application/json")
        except Exception as exc:
            st.error(str(exc))
with tabs[1]:
    st.subheader("Baseline vs Greedy")
    if st.button("Compare strategies"):
        st.code(capture(planner.command_compare, "builtin", use_matrix), language="text")
with tabs[2]:
    st.subheader("Eisenhower priority matrix")
    include_all = st.checkbox("Include already-mastered topics", value=False)
    if st.button("Show priority matrix"):
        st.code(capture(planner.print_matrix, ds, include_all), language="text")
with tabs[3]:
    st.subheader("Dataset validation")
    if st.button("Validate built-in dataset"):
        st.success("Built-in dataset loaded and validated.")
        st.code(capture(planner.print_dataset_summary, ds), language="text")
with tabs[4]:
    st.markdown("""
    This browser interface wraps the project's existing `learning_planner.py` implementation.

    **Available features:** Greedy and Baseline planning, optional Eisenhower prioritisation,
    missed-day simulation, strategy comparison, dataset summary, and CSV/JSON export.

    The interface runs in GitHub Codespaces and opens through a forwarded browser port.
    It does not require MinGW because it runs the Python edition, not the Windows-only C GUI.
    """)
